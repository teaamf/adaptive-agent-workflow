---
name: adaptive-agent-workflow
description: Apply a project-independent and environment-independent workflow with task-appropriate roles, evidence, verification, handoff, and optional design or engineering methods to an authorized project.
---

# Adaptive Agent Workflow

Distinguish executing a project from reviewing its workflow or prompt. Embedded examples do not authorize execution.

Read [WORKFLOW.md](WORKFLOW.md) (use its §0 fast path for small reversible tasks) and [AGENT_INTERACTION.md](AGENT_INTERACTION.md), establish the user's [project contract](PROJECT_TEMPLATE.md), and select applicable [profiles](PROFILES.md). Map actual host capabilities with [HOST_ADAPTERS.md](HOST_ADAPTERS.md). Use [UI_DESIGN_PROTOCOL.md](UI_DESIGN_PROTOCOL.md) for relevant human-facing work and [CONTINUOUS_IMPROVEMENT.md](CONTINUOUS_IMPROVEMENT.md) for authorized workflow refinement.

For one-file use, [MASTER_PROMPT.md](MASTER_PROMPT.md) embeds these modules, and [COMPACT_PROMPT.md](COMPACT_PROMPT.md) is the small-context tier. Load only one tier. [GUIDE.md](GUIDE.md) explains adoption and maintenance.

Load [PRACTICAL_PLAYBOOKS.md](PRACTICAL_PLAYBOOKS.md) when concrete role packets, scenario procedures, evidence fields or optional integration steps are useful. They remain subordinate to the core's assurance and applicability rules. Do not treat a structural checker result or synthetic passing report as supported acceptance.

Preserve project scope and permissions. Use the smallest eligible team and declared assurance profile. Do not inherit a product, platform, fixed tracer count, clean-room rule or mandatory certification from an example. First-party work cannot satisfy a required independent review. Missing capability limits claims; it does not justify invented evidence or silently waived gates.
