# Validation scope

29 September 2026. This report concerns the workflow document package, not an executed project or cross-host performance benchmark.

The mechanical checker validates master/companion consistency, local file links and a narrow guard against known historical product-name/requirement leakage. That last guard cannot detect all semantic project assumptions; author review is also needed.

The public generality cases G01–G18 were inspected against the rules, not executed as independent agent trials. Core §§2–4 distinguish project scope, assurance and actual capability; §7 supports existing projects and non-software deliverables; §§9–12 distinguish evidence, validity and scoped completion. PROFILES supplies task-specific methods without importing a product catalogue. This is author scenario inspection, not an independent certification.

No project was built, deployed or certified. No user study, controlled multi-project comparison or actual cross-host integration trial was performed. Future trials should use fresh cases, applicable domain expertise and the controls in CONTINUOUS_IMPROVEMENT.md.

The previous MolliKey package is preserved separately; the new package does not load it. Its 24 distributable files were compared byte-for-byte with its existing v3 ZIP and remain unchanged.

## Historical version 4.0 maintenance checks

- At version 4.0, the self-contained master matched its launch file and six canonical modules.
- Active local Markdown links resolve. This does not verify remote availability or every fragment anchor.
- The optional skill passed the Skill Creator frontmatter/discovery validator.
- The document helper ran in a relocated copy from a different working directory without changing the source package.
- A changed module caused a stale-master failure; assembly restored consistency.
- Deliberately introduced historical project-specific content was rejected even after assembly.
- A missing canonical module and a broken local link were each detected; clean checks passed after restoration.
- Ten helper invocations produced the expected exit results. These are document-tool checks, not ten development projects or agent trials.
- All 450 supplied design-advice title entries remain in the optional reference index.

Raw maintenance results are recorded in [research/document-check-results.json](research/document-check-results.json). The initial general draft and first research revision remain available as provenance. No runtime controller or certification service is included.


## Version 4.1 merge checks

The master now embeds seven canonical modules, including PRACTICAL_PLAYBOOKS.md. The updated master/companion and local-link checks passed. The optional skill validator passed. A relocated copy was checked, a modified playbook caused a stale-master failure, and a missing playbook was rejected; clean checks passed after restoration. These checks establish document maintenance behavior, not evidence truth or agent execution.

The two older source folders were compared to the pre-merge hash inventories and remain byte-for-byte unchanged. The pre-merge general package is preserved in its separate snapshot ZIP. No old checker, bytecode cache, synthetic passing report or live run-state fixture is included in the merged distributable.

The old checker was actually run read-only on its synthetic review fixture and returned LOCAL_READINESS with its structural-only caveat. This observed result motivated the new false-evidence example. Cases G19–G21 were inspected against playbooks O3–O4 and the core applicability rules; they were not run as independent agent trials. Their expected rejection is a protocol requirement, not an implemented semantic validator.

## Version 4.2 checks

The master now embeds eight canonical modules, adding AGENT_INTERACTION.md. The pre-edit package was snapshotted as `AdaptiveAgentWorkflow-pre-v4.2.zip` beside the directory. After reassembly, the document checker's consistency, link and leakage checks were rerun. New cases G22–G31 were inspected against the revised rules by the author. They were not run as agent trials. No new rule has comparative evidence in this package; see RESEARCH_AND_CHANGES research cycle 3 for sources and limits.

**Portability pass.** An audit of the operational files found four kinds of problem:

- leftovers from the origin project: a keyboard-specific UI example and a README reference;
- a project-specific guard hard-coded in the helper;
- vendor-specific instruction-file names in core rules;
- only one single-file tier, the 94 KB master, which is too large for small-context models.

Fixes:

- The leftovers were removed.
- The guard patterns moved to the editable `tools/portability_patterns.txt`. They now also cover vendor and model names and machine paths, and every operational file is scanned, not only the master.
- COMPACT_PROMPT.md was added (about 6.9 KB, with a 16 KB budget and required-rule markers checked).
- HOST_ADAPTERS gained loading tiers and a model-capability table.
- Portability cases G32–G36 were added.

Negative controls:

- A vendor name inserted into a module was rejected.
- A compact prompt missing a required rule was rejected.
- The original README leftover was detected before it was fixed.

These are document checks. The workflow has not been run on different models or hosts in this package, so cross-model behavior remains untested.

See [MERGE_DECISIONS.md](MERGE_DECISIONS.md) for accepted/rejected material and [research/merge-check-results.json](research/merge-check-results.json) for completed maintenance results.
